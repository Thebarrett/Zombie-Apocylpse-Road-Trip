#Hidden modes- 1930, 21, 1337, 7331

import random
done = False

rations_amount = 10
miles_traveled = 0
actions_left = 3
miles_left = 1654
horde_distance = 100
bike_quality = 100
days = 0

print("Welcome to the Zombie apocylpse roadtrip! \nYour goal is to get from Florida to Maine on bike...")
print()
while not done:
    print("||||||||||||||||||||||||||||||||||||||||||||||||")
    print("1. Eat your rations \n2. Ahead moderate speed \n3. Ahead full speed \n4. Stop and repair your bike \n5. Loot the area \n6. Status check \n7. Quit")
    print("||||||||||||||||||||||||||||||||||||||||||||||||")
    print()
    user_input = int(input("Select your choice:   "))
    if user_input == 7:
        print("Goodbye! you wimp")
        done = True


    elif miles_traveled >= 1654:
        print()
        print("You have made it to Maine! \nIt is nothing like what you've heard... \nThere are zombies everywhere... \nYou are dead.")
        done = True
    
    elif user_input == 1:
        horde_number = random.randrange(0, 61)
        if rations_amount > 0:
            rations_amount = rations_amount - 1
            print()
            my_list01 = ["You ate your rations peacefully","A zombie snuck up on you", "A zombie snuck up on you and you killed the zombie"]
            rng01 = random.randrange(3)
            print(my_list01[rng01])
            if my_list01[rng01] == "A zombie snuck up on you":
                done = True
            print()
            print("You have",rations_amount," rations left")
            actions_left = 3
            print()
            print("You have", actions_left, "actions left without eating or resting")
            print()
    
        else:
            print()
            print("You have no rations left")
            print("You will probably die soon")
            print()
    
    elif user_input == 2:
        my_number = random.randrange(0, 51)
        horde_number = random.randrange(0, 61)
        miles_traveled = miles_traveled + my_number
        print()
        print("You traveled", my_number, "miles")
        print()
        print("You have traveled", miles_traveled, "total miles" )
        print()
        miles_left = miles_left - my_number
        print("You have", miles_left, "miles left")
        print()
        my_list02 = ["You ran into a horde...","Nothing eventful happened", "You ran across a car, and drove it for 100 miles before it broke down", "You found some rations"]
        rng02 = random.randrange(4)
        print(my_list02[rng02])
        if my_list02[rng02] == "You ran into a horde... and you lost half your rations!":
            
            rations_amount = rations_amount / 2
        elif my_list02[rng02] == "You ran across a car, and drove it for 100 miles before it broke down":
            bike_quality = 100
            miles_traveled = miles_traveled + 100
        elif my_list02[rng02] == "You found some rations":
            rations_amount = rations_amount + 10
            print()
        print()
        days = days + 1
        print("You are", days, "days into your journey")
        print()
        actions_left = actions_left - 1
        print()
        print("You have", actions_left, "actions left without eating or resting")
        print()
        bike_quality = bike_quality - 25
        print("Your bike is at", bike_quality,"%")
        if bike_quality == 0:
            print()
            print("Your bike broke while you were riding it \nYou are dead.")
            done = True
        print()
        horde_distance = horde_distance + my_number
        print("The horde is", horde_distance, "miles away")
        print()
        my_number = 0
        if actions_left <= 0:
            print()
            print("You collapsed from starvation")
            done = True

    elif user_input == 3:
        my_number = random.randrange(51, 101)
        miles_traveled = miles_traveled + my_number
        print()
        print("You traveled", my_number, "miles")
        print()
        print("You have traveled", miles_traveled, "total miles" )
        print()
        miles_left = miles_left - my_number
        print("You have", miles_left, "miles left")
        print()
        my_list03 = ["You ran into a horde and died", "You found a bike repair kit", "You ran into a horde and lost all your rations", "You doubled your rations"]
        rng03 = random.randrange(4)
        print(my_list03[rng03])
        if my_list03[rng03] == "You ran into a horde and died":
            done = True
        elif my_list03[rng03] == "You found a bike repair kit":
            bike_quality = 200
        elif my_list03[rng03] == "You ran into a horde and lost all your rations":
            rations_amount = 0
        elif my_list03[rng03] == "You doubled your rations":
            rations_amount = rations_amount * 2
        print()
        days = days + 1
        print("You are", days, "days into your journey")
        print()
        actions_left = actions_left - 2
        print()
        print("You have", actions_left, "actions left without eating or resting")
        print()
        bike_quality = bike_quality - 50
        print("Your bike is at", bike_quality,"%")
        if bike_quality == 0:
            print()
            print("Your bike broke while you were riding it \nYou are dead.")
            done = True
        print()
        horde_distance = horde_distance + my_number
        print("The horde is", horde_distance, "miles away")
        print()
        my_number = 0
        if actions_left <= 0:
            print()
            print("You collapsed from starvation")
            done = True


    elif user_input == 4:
        horde_number = random.randrange(0, 101)
        print()
        print("You have to repair your bike...\nLet's hope zombies make you supper...")
        print()
        horde_distance = horde_distance - horde_number
        print("The horde is", horde_distance, "miles away")
        if horde_distance <=0:
            print("The horde has caught up with you...")
            done = True
        print()
        actions_left = actions_left - 1
        print("You have", actions_left, "actions left without eating or resting")
        print()
        bike_quality = 100
        print("Your bike is at", bike_quality,"%")
        days = days + 1
        print("You are", days, "days into your journey")
        print()


    elif user_input == 5:
        horde_number = random.randrange(0, 101)
        print()
        print("You have stopped in your local area to loot!")
        print()
        my_number = random.randrange(-1, 20)
        rations_amount = rations_amount + my_number
        print("You have",rations_amount," rations left")
        print()
        horde_distance = horde_distance - horde_number
        print("The horde is", horde_distance, "miles away")
        print()
        if horde_distance <=0:
            print("The horde has caught up with you...")
            done = True
        actions_left = actions_left - 2
        print()
        print("You have", actions_left, "actions left without eating or resting")
        if actions_left <= 0:
            print()
            print("You collapsed from starvation")
            done = True
        print()


    elif user_input == 6:
        print("You have", actions_left, "actions left without eating or resting")
        print()
        print("You have", miles_left, "miles left")
        print()
        print("You have traveled", miles_traveled, "total miles" )
        print()
        print("You have",rations_amount," rations left")
        print()
        print("The horde is", horde_distance, "miles away")
        print()
        print("You are", days, "days into your journey")
        print()


    elif user_input == 7331:
        

        print()
        print("||||||||||||||||||||||||||||||||||||||||||||||||")
        print()
        print("You find an old revolver on the ground... You decide to play \nrussian roullete")
        print()
        
        user_input = str(input("Do you wish to play? y/n:   "))
        print()
        if user_input == "y":
            
            ruskidone = False
            barrel_rotations = 0
            while not ruskidone:
                bullet = random.randrange(7)

                if bullet == 0:
                    print("Click...")
                    print()
                    barrel_rotations += 1 
                    if barrel_rotations == 5:
                        bullet == 5
                    


                elif bullet == 1:
                    print("Click...")
                    print()
                    barrel_rotations += 1 
                    if barrel_rotations == 5:
                        
                        bullet == 5
                    


                elif bullet == 2:
                    print("Click...")
                    print()
                    barrel_rotations += 1 
                    if barrel_rotations == 5:
                        bullet == 5

                elif bullet == 3:
                    print("Click...")
                    print()
                    barrel_rotations += 1
                    if barrel_rotations == 5:
                        bullet == 5

                elif bullet == 4:
                    print("Click...")
                    print()
                    barrel_rotations += 1 
                    if barrel_rotations == 5:
                        bullet == 5

                elif bullet == 5:
                    print("Bang!")
                    print()
                    ruskidone = True 
                    done = True

                elif bullet == 6:
                    print("The gun jammed... \nYou are lucky to be alive...")
                    ruskidone = True
            
        print()
        print("||||||||||||||||||||||||||||||||||||||||||||||||")
        print()
        

            
        
        
    elif user_input == 21:
        print()
        print("You ran into a zombie dressed up in gambler attire \nIt seems to be motioning you to play Blackjack")
        blkjack1 = False
        while not blkjack1:
            dealercards1 = random.randrange(1,12)
            dealercards2 = random.randrange(1,12)
            cards1 = random.randrange(1,12)
            cards2 = random.randrange(1,12)
            cardstotal = cards1 + cards2
            dealertotal = dealercards1 + dealercards2
            print()
            print("||||||||||||||||||||||||||||||||||||||||||||||||")
            blkjack2 = False
            while not blkjack2:
                
                print("You have", cardstotal)
                print()
                print("From what you see of the dealers cards he has", dealercards2)
                print()
                
                if cardstotal == 21:
                    print("You have blackjack!")
                    print()
                    blkjack2 = True
                print("Choose your option: \n1. Hit \n2. Stand \n3. Quit")
                print()
                user_input = int(input())
                print()
                if user_input == 1:
                    hitcards = random.randrange(1,12)
                    cards1 = hitcards
                    cardstotal += cards1
                    print()
                    if cardstotal > 21:
                        print("Bust!")
                        print()
                        blkjack2 = True
                    
                elif cardstotal > 21:
                    print("Bust!")
                    print()
                    blkjack2 = True
                elif cardstotal == 21:
                    print("Blackjack!")
                    blkjack2 = True

                elif user_input == 2:
                    stand = False
                    while not stand:
                        
                        print("The dealer has revealed his cards... \n He has", dealertotal)
                        print()

                        if dealertotal == 21:
                            print("The dealer won")
                            print()
                            blkjack2 = True
                        elif dealertotal >= 17:
                            print("The dealer stands!")
                            print()
                        if cardstotal >= dealertotal:
                             
                            print("You won!")
                            print()
                            stand = True
                            blkjack2 = True


                        elif dealertotal < 17:
                            
                            dealercards2 = random.randrange(1,12)
                            dealertotal += dealercards2
                            print("The dealer has", dealertotal)
                            print()
                
                elif user_input == 3:
                    blkjack1 = True
                    blkjack2 = True
                    
                            
                
                
                

    
    elif user_input == 1337:
        
        print()
        print("You found a friendly zombie! \nIt seems to be motioning you to play Rock, Paper, Scissors!")
        print()
        rps_done = False
        while not rps_done:
    
            print()
            print("||||||||||||||||||||||||||||||||||||||||||||||||")
            print()
            print("1 = Rock")
            print("2 = Paper")
            print("3 = Scissors")
            print("Enter 10 to run away from the insane Zombie")
            print()
            print("||||||||||||||||||||||||||||||||||||||||||||||||")
            print()
            good_selection = False
            while not good_selection:
                user_input = int(input("Enter your selection:   "))
                if user_input == 10:
                    print()
                    print("You ran away from that insane zombie!")
                    print()
                    rps_done = True
                if user_input == 1 or user_input == 2 or user_input == 3 or user_input == 10:
                    good_selection = True 
                else:
            
                    print("Please enter a 1, 2, or a 3")
                    good_selection = False

                

            ai_attack = random.randrange(3)

            if ai_attack == 0:
                if user_input == 1:
                    print("The Zombie chose rock")
                    print("Tie!")
                if user_input == 2:
                    print("The Zombie chose rock")
                    print("You lose!")
                if user_input == 3:
                    print("The Zombie chose rock")
                    print("You win!")

            if ai_attack == 1:
                if user_input == 1:
                    print("The Zombie chose paper")
                    print("You win!")
                if user_input == 2:
                    print("The Zombie chose paper")
                    print("Tie!")
                if user_input == 3:
                    print("The Zombie chose paper")
                    print("You lose!")


            if ai_attack == 2:
                if user_input == 1:
                    print("The Zombie chose scissors")
                    print("You lose!")
                if user_input == 2:
                    print("The Zombie chose scissors")
                    print("You win!")
                if user_input == 3:
                    print("The Zombie chose scissors")
                    print("Tie!")

    elif user_input == 1930:
        print()
        print("Written by by Barrett Wells")
        print()
        print("Written 3/7/22")
        print()
        print("________________________________________________")
        print("|                                              |")
        print("|                                              |")
        print("|                                              |")
        print("|                                              |")
        print("|           Welcome to the Easter Egg          |")
        print("|               Thats all folks!               |")
        print("|                                              |")
        print("|                                              |")
        print("|                                              |")
        print("|______________________________________________|")
        done = True

